package poly.com.lab4;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class CalculateServlet
 */
@WebServlet({"/calculate","/calculate/add", "/calculate/sub"})
public class CalculateServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.setAttribute("message", "Nhập số và chọn phép tính");
        req.getRequestDispatcher("/calculate.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        double a = Double.parseDouble(req.getParameter("a"));
        double b = Double.parseDouble(req.getParameter("b"));
        String path = req.getServletPath();

        if (path.endsWith("/add")) {
            req.setAttribute("message", a + " + " + b + " = " + (a + b));
        } else {
            req.setAttribute("message", a + " - " + b + " = " + (a - b));
        }

        req.getRequestDispatcher("/calculate.jsp").forward(req, resp);
    }

}
