package poly.com.lab4;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class RegisterServlet
 */
@WebServlet("/register")
public class RegisterServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
	    @Override
	    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
	        req.getRequestDispatcher("/register.jsp").forward(req, resp);
	    }

	    @Override
	    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
	            throws ServletException, IOException {
	        String fullname = req.getParameter("fullname");
	        String gender = req.getParameter("gender");
	        String[] hobby = req.getParameterValues("hobby");
	        String country = req.getParameter("country");

	        System.out.println("Họ tên: " + fullname);
	        System.out.println("Giới tính: " + gender);
	        System.out.println("Sở thích: " + Arrays.toString(hobby));
	        System.out.println("Quốc tịch: " + country);

	        req.setAttribute("message", "Đăng ký thành công!");
	        req.getRequestDispatcher("/register.jsp").forward(req, resp);
	    }
	}

