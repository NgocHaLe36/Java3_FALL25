package com.poly.servlet;
//import lombok.Getter;
//import lombok.Setter;
//
//@Getter
//@Setter
//public class User {
//    private String fullname;
//    private boolean gender;
//    private String country;
//}
import java.io.Serializable;

public class User implements Serializable {
    private String fullname;
    private boolean gender;
    private String country;

    public User() { }

    public String getFullname() {
        return fullname;
    }
    public void setFullname(String fullname) {
        this.fullname = fullname;
    }

    public boolean isGender() {
        return gender;
    }
    public void setGender(boolean gender) {
        this.gender = gender;
    }

    public String getCountry() {
        return country;
    }
    public void setCountry(String country) {
        this.country = country;
    }
}
