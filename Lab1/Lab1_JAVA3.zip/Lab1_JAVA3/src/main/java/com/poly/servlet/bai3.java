package com.poly.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class bai3
 */
@WebServlet("/bai3")
public class bai3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	@Override
    protected void doGet(HttpServletRequest request, HttpServletResponse response)
            throws ServletException, IOException {
        
        response.setContentType("text/html;charset=UTF-8");
        var out = response.getWriter();

        out.println("<html><body>");
        out.println("<h2>THÔNG TIN ĐỊA CHỈ URL</h2>");
        out.println("<ul>");
        out.println("<li><b>URL:</b> " + request.getRequestURL() + "</li>");
        out.println("<li><b>URI:</b> " + request.getRequestURI() + "</li>");
        out.println("<li><b>QueryString:</b> " + request.getQueryString() + "</li>");
        out.println("<li><b>ServletPath:</b> " + request.getServletPath() + "</li>");
        out.println("<li><b>ContextPath:</b> " + request.getContextPath() + "</li>");
        out.println("<li><b>PathInfo:</b> " + request.getPathInfo() + "</li>");
        out.println("<li><b>Method:</b> " + request.getMethod() + "</li>");
        out.println("</ul>");
        out.println("</body></html>");
    }
}
