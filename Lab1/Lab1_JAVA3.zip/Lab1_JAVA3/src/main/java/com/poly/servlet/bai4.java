package com.poly.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class bai4
 */

@WebServlet({"/bai4/create", "/bai4/update", "/bai4/delete", "/bai4/edit"})
public class bai4 extends HttpServlet {
	private static final long serialVersionUID = 1L;
	    @Override
	    protected void doGet(HttpServletRequest request, HttpServletResponse response)
	            throws ServletException, IOException {

	        response.setContentType("text/html;charset=UTF-8");
	        var out = response.getWriter();

	        String path = request.getServletPath();
	        String message = "";

	        switch (path) {
	            case "/bai4/create":
	                message = "Ban dang goi chuc nang CREATE";
	                break;
	            case "/bai4/update":
	                message = "Ban dang goi chuc nang UPDATE";
	                break;
	            case "/bai4/delete":
	                message = "Ban dang goi chuc nang DELETE";
	                break;
	            case "/bai4/edit":
	                message = "Ban dang goi chuc nang EDIT 2024";
	                break;
	            default:
	                message = "Khong ton tai duong dan yeu cau!";
	        }

	        out.println("<html><body>");
	        out.println("<h2>" + message + "</h2>");
	        out.println("</body></html>");
	    }

}
