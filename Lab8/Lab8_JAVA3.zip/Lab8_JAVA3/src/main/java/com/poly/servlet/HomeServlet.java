package com.poly.servlet;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet({"/home/index", "/home/about", "/home/contact"})
public class HomeServlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        String uri = req.getRequestURI();
        String contextPath = req.getContextPath();
        String path = uri.substring(contextPath.length()); // Lấy /home/contact

        String view = "/views/home/index.jsp"; // Mặc định

        if (path.endsWith("/home/index")) {
            view = "/views/home/index.jsp";
        } else if (path.endsWith("/home/about")) {
            view = "/views/home/about.jsp";
        } else if (path.endsWith("/home/contact")) {
            view = "/views/home/contact.jsp";
        }

        req.setAttribute("view", view);
        req.getRequestDispatcher("/views/layout.jsp").forward(req, resp);
    }
}