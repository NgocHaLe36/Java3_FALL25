package poly.com.filte;

import java.io.IOException;
import javax.servlet.*;
import javax.servlet.annotation.WebFilter;
import javax.servlet.http.*;

@WebFilter("/*")
public class I18nFilter implements Filter {

    @Override
    public void doFilter(ServletRequest request, ServletResponse response, FilterChain chain)
            throws IOException, ServletException {

        HttpServletRequest req = (HttpServletRequest) request;

        String lang = req.getParameter("lang"); // lấy lang trên URL

        if (lang != null) {
            req.getSession().setAttribute("lang", lang); // lưu session
        }

        chain.doFilter(request, response);
    }
}