// src/main/java/poly/servlet/EmployeeServlet.java
package poly.servlet;

import java.io.IOException;
import java.nio.file.*;

import javax.servlet.ServletException;
import javax.servlet.annotation.MultipartConfig;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.Part;

import poly.dao.*;
import poly.entity.Employee;

@MultipartConfig
@WebServlet({
    "/employee/index",
    "/employee/edit/*",
    "/employee/create",
    "/employee/update",
    "/employee/delete",
    "/employee/reset"
})
public class EmployeeServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Employee form = new Employee();
        EmployeeDAO empDao = new EmployeeDAOImpl();
        DepartmentDAO deptDao = new DepartmentDAOImpl();

        // ===============================
        // ✅ XỬ LÝ UPLOAD ẢNH (CHỈ multipart)
        // ===============================
        String ctype = req.getContentType();
        if (ctype != null && ctype.startsWith("multipart/")) {
            Part part = req.getPart("photoFile");
            if (part != null && part.getSize() > 0) {
                String filename = Paths.get(part.getSubmittedFileName()).getFileName().toString();

                // ✅ Giới hạn độ dài tên file để tránh lỗi truncate
                int maxLength = 255; // bằng kích thước cột Photo trong SQL Server
                if (filename.length() > maxLength) {
                    String ext = "";
                    int dotIndex = filename.lastIndexOf('.');
                    if (dotIndex > 0) {
                        ext = filename.substring(dotIndex); // giữ phần mở rộng .jpg/.png
                    }
                    filename = filename.substring(0, maxLength - ext.length()) + ext;
                }

                String realPath = getServletContext().getRealPath("/images/");

                if (!Files.exists(Paths.get(realPath))) {
                    Files.createDirectories(Paths.get(realPath));
                }

                part.write(realPath + filename);
                form.setPhoto(filename);
            }
        }

        // ===============================
        // ✅ LẤY TỪNG GIÁ TRỊ TRONG FORM (KHÔNG DÙNG BeanUtils)
        // ===============================
        form.setId(req.getParameter("id"));
        form.setFullname(req.getParameter("fullname"));

        // birthday
        String bday = req.getParameter("birthday");
        if (bday != null && !bday.isEmpty()) {
            form.setBirthday(java.sql.Date.valueOf(bday));
        }

        // gender
        String gender = req.getParameter("gender");
        if (gender != null) {
            form.setGender(Boolean.valueOf(gender));
        }

        // salary
        String sal = req.getParameter("salary");
        if (sal != null && !sal.isEmpty()) {
            form.setSalary(Double.parseDouble(sal));
        }

        // department
        form.setDepartmentId(req.getParameter("departmentId"));

        String uri = req.getRequestURI();

        // ===============================
        // ✅ XỬ LÝ CÁC CHỨC NĂNG CRUD
        // ===============================
        if (uri.contains("/edit/")) {
            String id = uri.substring(uri.lastIndexOf("/") + 1);
            form = empDao.findById(id);
            if (form == null) {
                req.setAttribute("error", "Không tìm thấy nhân viên!");
            }

        } else if (uri.contains("/create")) {
            try {
                empDao.create(form);
                req.setAttribute("success", "Thêm thành công!");
                form = new Employee();
            } catch (RuntimeException e) {
                req.setAttribute("error", e.getMessage());
            }

        } else if (uri.contains("/update")) {

            // ✅ Lấy dữ liệu cũ
            Employee old = empDao.findById(form.getId());

            // ✅ Nếu không chọn ảnh mới → giữ ảnh cũ
            if (form.getPhoto() == null || form.getPhoto().isEmpty()) {
                form.setPhoto(old.getPhoto());
            }

            try {
                empDao.update(form);
                req.setAttribute("success", "Cập nhật thành công!");
            } catch (RuntimeException e) {
                req.setAttribute("error", e.getMessage());
            }

        } else if (uri.contains("/delete")) {

            try {
                empDao.deleteById(form.getId());
                req.setAttribute("success", "Xóa thành công!");
                form = new Employee();
            } catch (RuntimeException e) {
                req.setAttribute("error", e.getMessage());
            }

        } else if (uri.contains("/reset")) {
            form = new Employee();
        }

        // ===============================
        // ✅ LUÔN LOAD DANH SÁCH PHÒNG BAN & NHÂN VIÊN
        // ===============================
        req.setAttribute("depts", deptDao.findAll());
        req.setAttribute("list", empDao.findAll());
        req.setAttribute("item", form);

        // ✅ CHUYỂN TỚI JSP
        req.getRequestDispatcher("/views/employee.jsp").forward(req, resp);
    }
}
