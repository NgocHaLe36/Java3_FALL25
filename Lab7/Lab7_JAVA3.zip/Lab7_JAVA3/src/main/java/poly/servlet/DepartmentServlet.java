// src/main/java/poly/servlet/DepartmentServlet.java
package poly.servlet;


import java.io.IOException;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poly.dao.*;
import poly.entity.Department;
import org.apache.commons.beanutils.BeanUtils;

@WebServlet({
    "/department/index",
    "/department/edit/*",
    "/department/create",
    "/department/update",
    "/department/delete",
    "/department/reset"
})
public class DepartmentServlet extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void service(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        req.setCharacterEncoding("UTF-8");
        resp.setContentType("text/html;charset=UTF-8");

        Department form = new Department();
        DepartmentDAO dao = new DepartmentDAOImpl();

        try {
            BeanUtils.populate(form, req.getParameterMap());
        } catch (Exception e) {
            req.setAttribute("error", "Lỗi xử lý form!");
        }

        String uri = req.getRequestURI();

        // 1. EDIT
        if (uri.contains("/edit/")) {
            String id = uri.substring(uri.lastIndexOf("/") + 1);
            form = dao.findById(id);
            if (form == null) {
                req.setAttribute("error", "Không tìm thấy phòng ban!");
            }
        }

        // 2. CREATE
        else if (uri.contains("/create")) {
            if (form.getId() == null || form.getId().trim().isEmpty()) {
                req.setAttribute("error", "Id không được để trống!");
            } else if (form.getName() == null || form.getName().trim().isEmpty()) {
                req.setAttribute("error", "Tên không được để trống!");
            } else {
                try {
                    dao.create(form);
                    req.setAttribute("success", "Thêm thành công!");
                    form = new Department();
                } catch (RuntimeException e) {
                    req.setAttribute("error", e.getMessage());
                }
            }
        }

        // 3. UPDATE
        else if (uri.contains("/update")) {
            if (form.getId() == null || form.getId().trim().isEmpty()) {
                req.setAttribute("error", "Chọn phòng ban cần sửa!");
            } else {
                try {
                    dao.update(form);
                    req.setAttribute("success", "Cập nhật thành công!");
                } catch (RuntimeException e) {
                    req.setAttribute("error", e.getMessage());
                }
            }
        }

        // 4. DELETE
        else if (uri.contains("/delete")) {
            if (form.getId() == null || form.getId().trim().isEmpty()) {
                req.setAttribute("error", "Chọn phòng ban cần xóa!");
            } else {
                try {
                    dao.deleteById(form.getId());
                    req.setAttribute("success", "Xóa thành công!");
                    form = new Department();
                } catch (RuntimeException e) {
                    req.setAttribute("error", e.getMessage());
                }
            }
        }

        // 5. RESET
        else if (uri.contains("/reset")) {
            form = new Department();
            req.setAttribute("success", "Form đã được làm mới!");
        }

        // Luôn load danh sách
        req.setAttribute("item", form);
        req.setAttribute("list", dao.findAll());

        req.getRequestDispatcher("/views/department.jsp").forward(req, resp);
    }
}