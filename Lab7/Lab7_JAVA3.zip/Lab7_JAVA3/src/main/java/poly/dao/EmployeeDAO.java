// src/main/java/poly/dao/EmployeeDAO.java
package poly.dao;

import java.util.List;
import poly.entity.Employee;

public interface EmployeeDAO {
    List<Employee> findAll();
    Employee findById(String id);
    void create(Employee e);
    void update(Employee e);
    void deleteById(String id);
}