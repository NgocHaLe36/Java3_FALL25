// src/main/java/poly/dao/EmployeeDAOImpl.java
package poly.dao;

import java.sql.*;
import java.util.*;
import poly.entity.Employee;
import poly.utils.Jdbc;

public class EmployeeDAOImpl implements EmployeeDAO {

    @Override
    public List<Employee> findAll() {
        String sql = "SELECT * FROM Employees";
        try {
            List<Employee> list = new ArrayList<>();
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setFullname(rs.getString("Fullname"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setGender(rs.getBoolean("Gender"));
                e.setPhoto(rs.getString("Photo"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                list.add(e);
            }
            return list;
        } catch (SQLException ex) {
            throw new RuntimeException("Lỗi truy vấn danh sách nhân viên: " + ex.getMessage(), ex);
        }
    }

    @Override
    public Employee findById(String id) {
        String sql = "SELECT * FROM Employees WHERE Id = ?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if (rs.next()) {
                Employee e = new Employee();
                e.setId(rs.getString("Id"));
                e.setFullname(rs.getString("Fullname"));
                e.setBirthday(rs.getDate("Birthday"));
                e.setGender(rs.getBoolean("Gender"));
                e.setPhoto(rs.getString("Photo"));
                e.setSalary(rs.getDouble("Salary"));
                e.setDepartmentId(rs.getString("DepartmentId"));
                return e;
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Không tìm thấy nhân viên Id: " + id, ex);
        }
        return null;
    }

    @Override
    public void create(Employee e) {
        String sql = "INSERT INTO Employees (Id, Fullname, Birthday, Gender, Photo, Salary, DepartmentId) VALUES (?, ?, ?, ?, ?, ?, ?)";
        try {
            Jdbc.executeUpdate(sql,
                e.getId(),
                e.getFullname(),
                e.getBirthday(),
                e.getGender(),
                e.getPhoto(),
                e.getSalary(),
                e.getDepartmentId()
            );
        } catch (SQLException ex) {
            if (ex.getMessage().contains("PRIMARY KEY") || ex.getMessage().contains("duplicate")) {
                throw new RuntimeException("Lỗi: Id '" + e.getId() + "' đã tồn tại! Vui lòng chọn Id khác.");
            }
            throw new RuntimeException("Thêm nhân viên thất bại: " + ex.getMessage(), ex);
        }
    }

    @Override
    public void update(Employee e) {
        String sql = "UPDATE Employees SET Fullname = ?, Birthday = ?, Gender = ?, Photo = ?, Salary = ?, DepartmentId = ? WHERE Id = ?";
        try {
            int rows = Jdbc.executeUpdate(sql,
                e.getFullname(),
                e.getBirthday(),
                e.getGender(),
                e.getPhoto(),
                e.getSalary(),
                e.getDepartmentId(),
                e.getId()
            );
            if (rows == 0) {
                throw new RuntimeException("Không tìm thấy nhân viên để cập nhật!");
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Cập nhật nhân viên thất bại: " + ex.getMessage(), ex);
        }
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Employees WHERE Id = ?";
        try {
            int rows = Jdbc.executeUpdate(sql, id);
            if (rows == 0) {
                throw new RuntimeException("Không tìm thấy nhân viên để xóa!");
            }
        } catch (SQLException ex) {
            throw new RuntimeException("Xóa nhân viên thất bại: " + ex.getMessage(), ex);
        }
    }
}