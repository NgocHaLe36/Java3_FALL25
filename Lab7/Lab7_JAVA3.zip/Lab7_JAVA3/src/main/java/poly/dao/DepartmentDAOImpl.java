// src/main/java/poly/dao/DepartmentDAOImpl.java
package poly.dao;

import java.sql.*;
import java.util.*;
import poly.entity.Department;
import poly.utils.Jdbc;

public class DepartmentDAOImpl implements DepartmentDAO {

	@Override
    public List<Department> findAll() {
        String sql = "SELECT * FROM Departments";
        List<Department> list = new ArrayList<>();

        try {
            ResultSet rs = Jdbc.executeQuery(sql);
            while (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                list.add(d);
            }
            rs.getStatement().getConnection().close();
            return list;
        } catch (Exception e) {
            throw new RuntimeException("Loi doc danh sach phong ban", e);
        }
    }

    @Override
    public Department findById(String id) {
        String sql = "SELECT * FROM Departments WHERE Id=?";
        try {
            ResultSet rs = Jdbc.executeQuery(sql, id);
            if (rs.next()) {
                Department d = new Department();
                d.setId(rs.getString("Id"));
                d.setName(rs.getString("Name"));
                d.setDescription(rs.getString("Description"));
                return d;
            }
        } catch (Exception e) {
            throw new RuntimeException("Loi tim phong ban", e);
        }
        return null;
    }

    @Override
    public void create(Department d) {
        String sql = "INSERT INTO Departments(Id, Name, Description) VALUES(?, ?, ?)";
        try {
            Jdbc.executeUpdate(sql, d.getId(), d.getName(), d.getDescription());
        } catch (SQLException e) {
            if (e.getMessage().contains("Violation of PRIMARY KEY") || 
                e.getMessage().contains("duplicate key")) {
                throw new RuntimeException("Lỗi: Id '" + d.getId() + "' đã tồn tại! Vui lòng nhập Id khác.");
            } else {
                throw new RuntimeException("Thêm thất bại: " + e.getMessage());
            }
        }
    }

    @Override
    public void update(Department d) {
        String sql = "UPDATE Departments SET Name=?, Description=? WHERE Id=?";
        try {
            int rows = Jdbc.executeUpdate(sql, d.getName(), d.getDescription(), d.getId());
            if (rows == 0) {
                throw new RuntimeException("Không tìm thấy Id để cập nhật!");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Cập nhật thất bại: " + e.getMessage());
        }
    }

    @Override
    public void deleteById(String id) {
        String sql = "DELETE FROM Departments WHERE Id=?";
        try {
            int rows = Jdbc.executeUpdate(sql, id);
            if (rows == 0) {
                throw new RuntimeException("Không tìm thấy Id để xóa!");
            }
        } catch (SQLException e) {
            throw new RuntimeException("Xóa thất bại: " + e.getMessage());
        }
    }
}