package poly.com.utils;

import java.sql.*;

public class Jdbc {
    static String driver = "com.microsoft.sqlserver.jdbc.SQLServerDriver";
    static String dburl = "jdbc:sqlserver://localhost:1433;database=Lab6_JAVA3;trustServerCertificate=true;encrypt=true";
    static String username = "sa";
    static String password = "123456";

    static {
        try {
            Class.forName(driver);
        } catch (ClassNotFoundException e) {
            throw new RuntimeException(e);
        }
    }

    public static Connection getConnection() throws SQLException {
        return DriverManager.getConnection(dburl, username, password);
    }

    public static int executeUpdate(String sql) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        int rows = stmt.executeUpdate(sql);
        stmt.close();
        conn.close();
        return rows;
    }

    public static ResultSet executeQuery(String sql) throws SQLException {
        Connection conn = getConnection();
        Statement stmt = conn.createStatement();
        return stmt.executeQuery(sql);
    }

    // PreparedStatement
    public static int executeUpdate(String sql, Object... params) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
        int rows = ps.executeUpdate();
        ps.close();
        conn.close();
        return rows;
    }

    public static ResultSet executeQuery(String sql, Object... params) throws SQLException {
        Connection conn = getConnection();
        PreparedStatement ps = conn.prepareStatement(sql);
        for (int i = 0; i < params.length; i++) {
            ps.setObject(i + 1, params[i]);
        }
        return ps.executeQuery();
    }

    // CallableStatement
    public static ResultSet callStoredProcedure(String procName, Object... params) throws SQLException {
        Connection conn = getConnection();
        String call = "{call " + procName + "(?" + ", ?".repeat(params.length - 1) + ")}";
        CallableStatement cs = conn.prepareCall(call);
        for (int i = 0; i < params.length; i++) {
            cs.setObject(i + 1, params[i]);
        }
        return cs.executeQuery();
    }
}