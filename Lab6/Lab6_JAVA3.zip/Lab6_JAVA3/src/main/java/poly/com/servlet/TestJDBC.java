package poly.com.servlet;

import java.io.IOException;
import java.io.PrintWriter;
import java.sql.ResultSet;
import java.sql.SQLException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import poly.com.utils.Jdbc;

@WebServlet("/test-jdbc")
public class TestJDBC extends HttpServlet {
    private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<h2>TEST JDBC - STATEMENT</h2>");

        try {
            // BƯỚC 1: XÓA DỮ LIỆU CŨ ĐỂ TRÁNH TRÙNG KHÓA
            Jdbc.executeUpdate("DELETE FROM Departments WHERE Id = 'MK'");

            // BƯỚC 2: THÊM MỚI → LUÔN THÀNH CÔNG
            int rows = Jdbc.executeUpdate("INSERT INTO Departments VALUES ('MK', N'Phòng Marketing', N'Phòng marketing')");
            out.println("<p style='color:green; font-weight:bold;'>Thêm thành công " + rows + " phòng ban (MK).</p>");

            // BƯỚC 3: HIỂN THỊ BẢNG
            ResultSet rs = Jdbc.executeQuery("SELECT * FROM Departments ORDER BY Id");
            out.println("<table border='1' style='margin:10px 0; width:100%;'><tr><th>Id</th><th>Name</th><th>Description</th></tr>");
            while (rs.next()) {
                out.println("<tr><td>" + rs.getString("Id") + "</td><td>" + rs.getString("Name") + "</td><td>" + rs.getString("Description") + "</td></tr>");
            }
            out.println("</table>");
            rs.close();

        } catch (SQLException e) {
            out.println("<p style='color:red; font-weight:bold;'>Lỗi: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        resp.setContentType("text/html; charset=UTF-8");
        PrintWriter out = resp.getWriter();

        out.println("<h2>TEST JDBC - PREPARED & CALLABLE</h2>");

        try {
            // XÓA NHÂN VIÊN CŨ
            Jdbc.executeUpdate("DELETE FROM Employees WHERE Id = 'NV003'");

            // 1. PreparedStatement - THÊM NHÂN VIÊN MỚI
            int rows = Jdbc.executeUpdate(
                "INSERT INTO Employees VALUES (?, ?, ?, ?, ?, ?, ?, ?)",
                "NV003", "789", "Lê Văn C", "ava3.jpg", 1, "1992-03-03", 9000000.0, "MK"
            );
            out.println("<p style='color:green; font-weight:bold;'>Thêm nhân viên thành công " + rows + " bản ghi (NV003).</p>");

            // 2. PreparedStatement - TRUY VẤN LƯƠNG > 8TR
            ResultSet rs = Jdbc.executeQuery("SELECT * FROM Employees WHERE Salary > ?", 8000000.0);
            out.println("<h3>Nhân viên lương > 8 triệu</h3>");
            out.println("<table border='1' style='margin:10px 0; width:100%;'><tr><th>Id</th><th>Fullname</th><th>Salary</th></tr>");
            while (rs.next()) {
                out.println("<tr><td>" + rs.getString("Id") + "</td><td>" + rs.getString("Fullname") + "</td><td>" + rs.getFloat("Salary") + "</td></tr>");
            }
            out.println("</table>");
            rs.close();

            // 3. CallableStatement - GỌI STORED PROCEDURE
            ResultSet rsProc = Jdbc.callStoredProcedure("GetEmployeesBySalary", 8000000.0);
            out.println("<h3>Stored Procedure (lương >= 8 triệu)</h3>");
            out.println("<table border='1' style='margin:10px 0; width:100%;'><tr><th>Id</th><th>Fullname</th><th>Salary</th></tr>");
            while (rsProc.next()) {
                out.println("<tr><td>" + rsProc.getString("Id") + "</td><td>" + rsProc.getString("Fullname") + "</td><td>" + rsProc.getFloat("Salary") + "</td></tr>");
            }
            out.println("</table>");
            rsProc.close();

        } catch (SQLException e) {
            out.println("<p style='color:red; font-weight:bold;'>Lỗi: " + e.getMessage() + "</p>");
            e.printStackTrace();
        }
    }
}