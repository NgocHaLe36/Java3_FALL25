package poly.com.model;

import java.util.Properties;

import javax.mail.Authenticator;
import javax.mail.Message;
import javax.mail.PasswordAuthentication;
import javax.mail.Session;
import javax.mail.Transport;
import javax.mail.internet.InternetAddress;
import javax.mail.internet.MimeMessage;

public class Mailer {
    public static void send(String from, String to, String subject, String body) {
        Properties props = new Properties();
        props.put("mail.smtp.auth", "true");
        props.put("mail.smtp.starttls.enable", "true");
        props.put("mail.smtp.host", "smtp.gmail.com");
        props.put("mail.smtp.port", "587");

        // DEBUG: In ra console
        System.out.println("=== GỬI EMAIL ===");
        System.out.println("Từ: " + from);
        System.out.println("Đến: " + to);
        System.out.println("Tiêu đề: " + subject);

        Session session = Session.getInstance(props, new Authenticator() {
            @Override
            protected PasswordAuthentication getPasswordAuthentication() {
                String username = "halnts02076@gmail.com";           // EMAIL GỬI
                String password = "rhfx qdzx ndvo umby";             // APP PASSWORD CỦA BẠN
                System.out.println("Tài khoản: " + username);
                System.out.println("App Password: " + password);
                return new PasswordAuthentication(username, password);
            }
        });

        try {
            MimeMessage mail = new MimeMessage(session);
            mail.setFrom(new InternetAddress(from));
            mail.setRecipients(Message.RecipientType.TO, to);
            mail.setSubject(subject, "utf-8");
            mail.setText(body, "utf-8", "html");
            mail.setReplyTo(mail.getFrom());

            Transport.send(mail);
            System.out.println("GỬI EMAIL THÀNH CÔNG! Kiểm tra SPAM trong 5 phút.");
        } catch (Exception e) {
            System.err.println("LỖI GỬI EMAIL: " + e.getMessage());
            e.printStackTrace();
        }
    }
}