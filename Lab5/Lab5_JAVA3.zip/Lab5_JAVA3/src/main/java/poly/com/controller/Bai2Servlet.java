package poly.com.controller;

import java.io.IOException;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poly.com.model.Mailer;

@WebServlet("/lab5bai2")
public class Bai2Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;

    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        req.getRequestDispatcher("/lab5bai2.jsp").forward(req, resp);
    }

    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String from = req.getParameter("from");
        String to = req.getParameter("to");
        String subject = req.getParameter("subject");
        String body = req.getParameter("body");

        Mailer.send(from, to, subject, body);  // ĐÚNG ĐỀ BÀI

        req.setAttribute("msg", "ĐÃ GỬI EMAIL! Kiểm tra SPAM trong 5 phút.");
        doGet(req, resp);
    }
}