package poly.com.controller;

import java.io.IOException;
import java.util.Base64;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/lab5bai3")
public class Bai3Servlet extends HttpServlet {
	private static final long serialVersionUID = 1L;
    // doGet: Hiển thị form + Đọc cookie nếu có
    @Override
    protected void doGet(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {

        // ĐỌC COOKIE "user"
        Cookie[] cookies = req.getCookies();
        if (cookies != null) {
            for (Cookie c : cookies) {
                if (c.getName().equals("user")) {
                    String encoded = c.getValue();
                    byte[] bytes = Base64.getDecoder().decode(encoded);
                    String[] userInfo = new String(bytes).split(",");
                    req.setAttribute("username", userInfo[0]);
                    req.setAttribute("password", userInfo[1]);
                }
            }
        }
        req.getRequestDispatcher("/lab5bai3.jsp").forward(req, resp);
    }

    // doPost: Xử lý đăng nhập + Tạo cookie nếu tích Remember
    @Override
    protected void doPost(HttpServletRequest req, HttpServletResponse resp)
            throws ServletException, IOException {
        String username = req.getParameter("username");
        String password = req.getParameter("password");
        String remember = req.getParameter("remember-me");

        // KIỂM TRA ĐĂNG NHẬP
        if ("FPT".equalsIgnoreCase(username) && "poly".equals(password)) {
            req.setAttribute("message", "Login successfully!");

            // TẠO SESSION
            req.getSession().setAttribute("username", username);

            // TẠO COOKIE NẾU TÍCH "Remember me"
            if (remember != null) {
                byte[] bytes = (username + "," + password).getBytes();
                String encoded = Base64.getEncoder().encodeToString(bytes);
                Cookie cookie = new Cookie("user", encoded);
                cookie.setMaxAge(30 * 24 * 60 * 60); // 30 ngày
                cookie.setPath("/");
                resp.addCookie(cookie);
            }
        } else {
            req.setAttribute("message", "Invalid login info!");
        }
        doGet(req, resp);
    }
}