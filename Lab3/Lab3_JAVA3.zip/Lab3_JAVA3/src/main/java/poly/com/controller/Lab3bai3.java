package poly.com.controller;

import java.io.IOException;
import java.util.Date;
import java.util.HashMap;
import java.util.Map;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

/**
 * Servlet implementation class Lab3bai1
 */
@WebServlet({"/lab3bai3","/lab3bai4"})
public class Lab3bai3 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    @Override
    	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    		// TODO Auto-generated method stub
    	req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		String chon = req.getRequestURI();

		if (chon.contains("/lab3bai3")) {

		    Map<String, Object> map = new HashMap<>();
		    map.put("name", "Iphone 2024");
		    map.put("price", 12345678);
		    map.put("date", new Date());

		    req.setAttribute("item", map);
		    req.getRequestDispatcher("lab3bai3.jsp").forward(req, resp);

		} else {

		    Map<String, Object> map = new HashMap<>();
		    map.put("Title", "Tiêu đề bản tin");
		    map.put("content", "Nội dung bản tin thường rất là dài ");

		    req.setAttribute("item", map);
		    req.getRequestDispatcher("lab3bai5.jsp").forward(req, resp);
		}
    }
}
