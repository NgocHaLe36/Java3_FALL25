package poly.com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import poly.com.model.Country;

/**
 * Servlet implementation class Lab3bai1
 */
@WebServlet("/lab3bai1")
public class Lab3bai1 extends HttpServlet {
	private static final long serialVersionUID = 1L;
    @Override
    	protected void doGet(HttpServletRequest req, HttpServletResponse resp) throws ServletException, IOException {
    		// TODO Auto-generated method stub
    	req.setCharacterEncoding("UTF-8");
		resp.setCharacterEncoding("UTF-8");
		
		List<Country> list = List.of(
			new Country("VN","VietNam"),
			new Country("US","Mỹ"),
			new Country("CN","Trung Quốc")
			);
		req.setAttribute("countries", list);
		req.getRequestDispatcher("/lab3bai1.jsp").forward(req, resp);
    	}
}
